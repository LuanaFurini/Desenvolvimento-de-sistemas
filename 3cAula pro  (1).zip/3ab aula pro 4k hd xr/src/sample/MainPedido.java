package sample;

import sample.model.Pedido;

public class MainPedido {

    public static void main(String[] args) {

        Pedido pedido = new Pedido();
        pedido.setDescricao("srhth");
        pedido.setData("wrhaer");
        pedido.addItem("ewrhaeh", 1);
        pedido.addItem("aethaeth", 2);
        pedido.addItem("ethath", 3);

        System.out.println(pedido);


    }
}