package sample;


import sample.model.Ingrediente;
import sample.model.Receita;

public class MainIngredientes  {



    public static void main(String[] args) {

        Ingrediente ingrediente = new Ingrediente();
        ingrediente.setNome("Chocolate");
        ingrediente.setQtde(700);
        ingrediente.setUm("g");

        Receita receita = new Receita();
        receita.setNome("Torta Alemã");
        receita.setDescricao("receita mto boa msm recomendo");
        receita.setIngrediente(ingrediente);
        receita.setIngrediente("Ovos", 2, "unidade");
        receita.setIngrediente("Chocolate", 300, "g");

        System.out.println(receita);

    }
}