package sample;

import sample.model.Endereco;
import sample.model.Pessoa;

public class MainPessoaEndereco {

    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Felps");
        pessoa.setDataNascimento("26/09/2003");

        Endereco endereco = new Endereco();
        endereco.setRua("Nao e da sua conta");
        endereco.setNumero(666);
        endereco.setBairro("Somewhere");
        endereco.setCidade("Florianópolis");

        pessoa.setEndereco(endereco);

        System.out.println(pessoa);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Desconhecido");
        pessoa2.setDataNascimento("01/05/1721");
        pessoa2.setEndereco("Rio Nilo", 123, "Yuayef", "Londres");
        System.out.println(pessoa2);

    }
}
