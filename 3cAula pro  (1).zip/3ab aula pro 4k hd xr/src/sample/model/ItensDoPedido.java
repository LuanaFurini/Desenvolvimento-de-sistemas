package sample.model;

import java.util.ArrayList;
import java.util.List;

public class ItensDoPedido {
    private List<Produto> produtos;

    public ItensDoPedido(){
        produtos = new ArrayList<>();
    }
    public List<Produto> getProdutos() {
        return produtos;
    }
    public void setProduto(String nome, double preco) {
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setPreco(preco);
        this.produtos.add(produto);
    }

    @Override
    public String toString() {
        return "Produtos: " + produtos;
    }
}
