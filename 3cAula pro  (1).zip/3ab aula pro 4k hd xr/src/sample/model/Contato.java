package sample.model;

public class Contato {

    private String whatsapp;
    private String twitter;
    private String email;



    public void setWhatsapp(String whatsapp) {
        this.whatsapp = whatsapp;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
        }

    public String toString(){
        return "Whatsapp: " + whatsapp + ", E-mail: " + email + ", Twitter: " + twitter;
        }
        }
