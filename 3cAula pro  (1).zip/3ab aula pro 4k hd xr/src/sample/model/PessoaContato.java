package sample.model;

public class PessoaContato {

    private String nome;
    private Contato contato;

    public String getNome () {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Contato getContato() {
        return contato;
    }

    public void setContato (String whatsapp, String email, String twitter) {
        Contato contato = new Contato();
        contato.setWhatsapp(whatsapp);
        contato.setEmail(email);
        contato.setTwitter(twitter);
        this.contato = contato;
    }
    public String toString(){
        return "Nome: " + nome + ", " + contato;
    }
}
