package sample.model;

public class Pedido {
   private String descricao;
   private String data;
   private double total;
   private ItensDoPedido itens;

    public String getDescricao() {
        return descricao;
    }
    public void setDescricao (String descricao) {
        this.descricao = descricao;
    }
    public String getData () {
        return data;
    }
    public void setData(){
        this.data = data;
    }
    public double getTotal(){
        return total;
    }
    ///TODO: refazer
    public void setTotal(double total) {
        this.total = total;
    }
    public ItensDoPedido getItens() {
        return itens;
    }
    public void addItem(String nome, double preco) {
        this.itens.setProduto(nome,preco);
    }
    public String toString(){
        return  "Novo pedido\n"
                + "Descrição: " + descricao
                + " Data: " + data + "\n"
                + itens
                + "\n\nTotal: " + total;
    }
    

}
