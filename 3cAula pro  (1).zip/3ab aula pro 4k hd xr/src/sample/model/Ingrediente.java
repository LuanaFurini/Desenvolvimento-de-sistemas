package sample.model;

public class Ingrediente {
    private String nome;
    private double qtde;
    private String um;

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }
    public double getQtde(){
        return qtde;
    }
    public void setQtde(double gtde){
        this.qtde = qtde;
    }
    public String setUm(){
        return um;
    }
    @Override
    public String toString() {
        return nome + ", Quantidade: " + qtde +
                "Unidade de Medida: " + um;
    }
}
