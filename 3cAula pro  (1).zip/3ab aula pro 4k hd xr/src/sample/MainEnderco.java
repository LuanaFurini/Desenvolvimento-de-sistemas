package sample;

import sample.model.Endereco;

public class MainEnderco {

    public static void main(String[] args) {
        Endereco endereco = new Endereco();
        endereco.setRua("Rua");
        endereco.setNumero(777);
        endereco.setBairro("Vargem");
        endereco.setCidade("Florianópolis");

        System.out.println(endereco);
    }
}
