package sample;

import sample.model.Pessoa;

import java.util.ArrayList;
import java.util.List;

public class MainPessoa {

    public static void main(String []args){
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Felipe");
        pessoa.setDataNascimento("26/09/2003");

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Alex");
        pessoa2.setDataNascimento("06/01/1986");

        Pessoa pessoa3 = new Pessoa();
        pessoa3.setNome("Keanu");
        pessoa3.setDataNascimento("02/09/1964");

        List<Pessoa> pessoas = new ArrayList<>();
        pessoas.add(pessoa);
        pessoas.add(pessoa2);
        pessoas.add(pessoa3);
        System.out.println(pessoas);

        Pessoa pessoa4 = new Pessoa();
        pessoa4.setNome("Steve");
        pessoa4.setDataNascimento("16/08/1964");
        pessoas.add(pessoa4);
        System.out.println(pessoas);
    }
}
