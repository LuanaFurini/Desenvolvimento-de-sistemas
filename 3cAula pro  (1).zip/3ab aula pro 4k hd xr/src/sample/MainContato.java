package sample;

import sample.model.PessoaContato;

public class MainContato {

    public static void main(String[] args) {
        PessoaContato pessoa = new PessoaContato();
        pessoa.setNome("qaeyhwerh");
        pessoa.setContato("134246567", " eunf@rijgr", "ywefuyrfy");
        System.out.println(pessoa);
    }

}
